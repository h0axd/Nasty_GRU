prefix=$cmdpath
clear
echo
echo Prefix from bootefi.sh is $prefix
configfile $prefix/gnugrub.efisetup64.cfg
echo
echo