prefix=$cmdpath
clear
echo
echo Prefix from bootefi.sh is $prefix
configfile $prefix/gnugrub.efisetup32.cfg
echo
echo